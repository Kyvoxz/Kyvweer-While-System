require("dotenv").config();
const express = require("express");
const session = require("express-session");
const fs = require("fs");
const path = require("path");
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require("discord.js");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_FILE = path.join(__dirname, "data.json");
const adminIds = (process.env.ADMIN_IDS || "").split(",").map(x => x.trim()).filter(Boolean);

if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({ scripts: [], keys: [], admins: [] }, null, 2));
}
const readData = () => JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
const writeData = data => fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));

app.use(express.json({ limit: "1mb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-session-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 86400000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in with Discord." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || !adminIds.includes(req.session.user.id)) {
    return res.status(403).json({ error: "Admin access only." });
  }
  next();
}

app.get("/auth/discord", (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID || "",
    redirect_uri: process.env.DISCORD_REDIRECT_URI || "",
    response_type: "code",
    scope: "identify"
  });
  res.redirect("https://discord.com/oauth2/authorize?" + params.toString());
});

app.get("/auth/discord/callback", async (req, res) => {
  try {
    if (!req.query.code) return res.redirect("/?error=discord_login");
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID || "",
        client_secret: process.env.DISCORD_CLIENT_SECRET || "",
        grant_type: "authorization_code",
        code: String(req.query.code),
        redirect_uri: process.env.DISCORD_REDIRECT_URI || ""
      })
    });
    const token = await tokenResponse.json();
    if (!token.access_token) throw new Error("Could not obtain Discord access token");
    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${token.access_token}` }
    });
    const user = await userResponse.json();
    req.session.user = { id: user.id, username: user.username, avatar: user.avatar };
    res.redirect("/");
  } catch (e) {
    console.error(e);
    res.redirect("/?error=login_failed");
  }
});

app.post("/auth/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/me", (req, res) => res.json({
  user: req.session.user || null,
  isAdmin: !!req.session.user && adminIds.includes(req.session.user.id)
}));

app.get("/api/dashboard", requireLogin, (req, res) => {
  const d = readData();
  res.json({
    stats: { scripts: d.scripts.length, keys: d.keys.length, admins: adminIds.length + d.admins.length },
    scripts: d.scripts.map(({ id, name, description, updatedAt }) => ({ id, name, description, updatedAt })),
    keys: d.keys.map(({ id, label, status, createdAt }) => ({ id, label, status, createdAt }))
  });
});

app.post("/api/scripts", requireAdmin, (req, res) => {
  const { name, description, code } = req.body || {};
  if (!name || !code) return res.status(400).json({ error: "Name and Lua code are required." });
  const d = readData();
  const item = { id: cryptoId(), name: String(name).slice(0, 80), description: String(description || "").slice(0, 240), code: String(code), updatedAt: new Date().toISOString() };
  d.scripts.push(item); writeData(d); res.json({ ok: true, id: item.id });
});
app.delete("/api/scripts/:id", requireAdmin, (req, res) => {
  const d = readData(); d.scripts = d.scripts.filter(x => x.id !== req.params.id); writeData(d); res.json({ ok: true });
});
app.get("/api/scripts/:id/code", requireAdmin, (req, res) => {
  const item = readData().scripts.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Script not found." });
  res.type("text/plain").send(item.code);
});

app.post("/api/keys", requireAdmin, (req, res) => {
  const { label } = req.body || {};
  if (!label) return res.status(400).json({ error: "Add a label for this key." });
  const d = readData();
  const key = "KYV-" + cryptoId().toUpperCase() + "-" + cryptoId().toUpperCase();
  d.keys.push({ id: cryptoId(), key, label: String(label).slice(0, 80), status: "Active", createdAt: new Date().toISOString() });
  writeData(d); res.json({ ok: true, key });
});
app.delete("/api/keys/:id", requireAdmin, (req, res) => {
  const d = readData(); d.keys = d.keys.filter(x => x.id !== req.params.id); writeData(d); res.json({ ok: true });
});
app.get("/api/keys", requireAdmin, (req, res) => res.json(readData().keys));

function cryptoId() {
  return require("crypto").randomBytes(5).toString("hex");
}

// Optional Discord bot connection. The dashboard still runs if no bot token is configured.
let botStatus = "Not connected";
if (process.env.DISCORD_BOT_TOKEN) {
  const bot = new Client({ intents: [GatewayIntentBits.Guilds] });
  bot.once("ready", async () => {
    botStatus = `Online as ${bot.user.tag}`;
    try {
      const command = new SlashCommandBuilder().setName("kyvweer").setDescription("Open the Kyvweer.lol dashboard");
      const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN);
      await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: [command.toJSON()] });
    } catch (e) { console.error("Slash command registration:", e.message); }
    console.log(botStatus);
  });
  bot.on("interactionCreate", async interaction => {
    if (!interaction.isChatInputCommand() || interaction.commandName !== "kyvweer") return;
    await interaction.reply({ content: "Kyvweer.lol dashboard: " + (process.env.PUBLIC_URL || "http://localhost:3000"), ephemeral: true });
  });
  bot.login(process.env.DISCORD_BOT_TOKEN).catch(e => { botStatus = "Bot login failed"; console.error(e.message); });
}
app.get("/api/bot-status", requireLogin, (req, res) => res.json({ status: botStatus }));

app.listen(PORT, () => console.log(`Kyvweer.lol running at http://localhost:${PORT}`));
