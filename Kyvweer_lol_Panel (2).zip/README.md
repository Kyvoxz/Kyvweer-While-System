# Kyvweer.lol — Discord dashboard

A starter admin panel for your own Lua projects, with Discord sign-in, manual key generation/revocation, script storage, and an optional Discord bot slash command.

## 1. Requirements
- Node.js 20 or newer
- A Discord application and bot you own

## 2. Install
1. Extract this ZIP.
2. Open the extracted folder in File Explorer.
3. In the folder address bar type `cmd` and press Enter.
4. Run:
   ```bash
   npm install
   ```
5. Copy `.env.example` and rename the copy to `.env`.
6. Fill in the Discord values in `.env`. Never share your bot token or client secret.

## 3. Discord setup
1. Open https://discord.com/developers/applications and select your application.
2. Under **OAuth2**, add this redirect URI exactly for local testing:
   `http://localhost:3000/auth/discord/callback`
3. Copy the **Client ID** and **Client Secret** into `.env`.
4. Under **Bot**, reset/copy the bot token and put it in `DISCORD_BOT_TOKEN`.
5. Turn on no privileged intents; this panel only needs the Guilds intent.
6. Copy your Discord user ID (Developer Mode → right-click your profile → Copy User ID) into `ADMIN_IDS`. Only IDs listed there can create/delete scripts and keys.

## 4. Run
```bash
npm start
```
Open http://localhost:3000 and choose **Login with Discord**. The bot registers `/kyvweer` globally after it connects.

## 5. Important
- This is a working local starter, not a public website yet. To make it public, deploy it to a Node.js host and set `DISCORD_REDIRECT_URI`, `PUBLIC_URL`, `SESSION_SECRET`, and `NODE_ENV=production` to the deployed values.
- Use persistent storage on the host; this starter stores data in `data.json`.
- Do not commit `.env` or share your bot token/client secret. If a token was exposed, reset it in the Developer Portal.
- The generated keys are currently stored and displayed by the panel. They are not yet wired into a Roblox/Lua loader or an external verification service.
- The panel is in English, with manual keys and administrator-only editing as requested.
