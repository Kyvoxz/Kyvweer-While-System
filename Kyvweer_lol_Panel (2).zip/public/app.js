const $ = id => document.getElementById(id);
let isAdmin = false;
function toast(message){const t=$("toast");t.textContent=message;t.style.display="block";setTimeout(()=>t.style.display="none",2800)}
async function api(url, options={}){const r=await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||"Request failed");return data}
function showLogin(){ $("loginNotice").classList.remove("hidden");$("app").classList.add("hidden");$("login").classList.remove("hidden");$("logout").classList.add("hidden");}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function init(){
 try{
  const me=await api("/api/me");
  if(!me.user){showLogin();return}
  isAdmin=me.isAdmin;$("who").textContent=me.user.username+(isAdmin?" · Admin":" · Member");
  $("login").classList.add("hidden");$("logout").classList.remove("hidden");$("loginNotice").classList.add("hidden");$("app").classList.remove("hidden");
  document.querySelectorAll(".admin-only").forEach(x=>x.classList.toggle("hidden",!isAdmin));
  await load();
 }catch(e){showLogin();toast(e.message)}
}
async function load(){
 const d=await api("/api/dashboard");$("scriptCount").textContent=d.stats.scripts;$("keyCount").textContent=d.stats.keys;$("adminCount").textContent=d.stats.admins;
 $("scriptList").innerHTML=d.scripts.length?d.scripts.map(s=>`<div class="item"><div><b>${escapeHtml(s.name)}</b><small>${escapeHtml(s.description||"No description")}</small></div>${isAdmin?`<button class="danger" onclick="deleteScript('${s.id}')">Delete</button>`:""}</div>`).join(""):'<p class="muted">No scripts added yet.</p>';
 const keys=await api("/api/keys").catch(()=>[]);
 $("keyList").innerHTML=keys.length?keys.map(k=>`<div class="item"><div><b>${escapeHtml(k.label)}</b><small>${escapeHtml(k.key)} · ${escapeHtml(k.status)}</small></div><button class="outline" onclick="copyKey('${k.key}')">Copy</button><button class="danger" onclick="deleteKey('${k.id}')">Revoke</button></div>`).join(""):'<p class="muted">No keys available or you do not have admin access.</p>';
 const b=await api("/api/bot-status");$("botStatus").textContent=b.status;
}
window.deleteScript=async id=>{try{await api("/api/scripts/"+id,{method:"DELETE"});toast("Script deleted");load()}catch(e){toast(e.message)}};
window.deleteKey=async id=>{try{await api("/api/keys/"+id,{method:"DELETE"});toast("Key revoked");load()}catch(e){toast(e.message)}};
window.copyKey=async key=>{await navigator.clipboard.writeText(key);toast("Key copied")};
$("addScript").onclick=async()=>{try{await api("/api/scripts",{method:"POST",body:JSON.stringify({name:$("scriptName").value,description:$("scriptDesc").value,code:$("scriptCode").value})});$("scriptName").value=$("scriptDesc").value=$("scriptCode").value="";toast("Script saved");load()}catch(e){toast(e.message)}};
$("addKey").onclick=async()=>{try{const r=await api("/api/keys",{method:"POST",body:JSON.stringify({label:$("keyLabel").value})});$("keyLabel").value="";toast("New key: "+r.key);load()}catch(e){toast(e.message)}};
$("logout").onclick=async()=>{await api("/auth/logout",{method:"POST"});showLogin()};
init();